import pandas as pd
import numpy as np
import subprocess
import sys
from sklearn.preprocessing import StandardScaler, LabelEncoder

def preprocess(file_path):
    df = pd.read_csv(file_path)
    df.columns = df.columns.str.strip().str.replace('\t', '')

    df.drop_duplicates(inplace=True) 
# Fill missing values for numeric columns only
    numeric_cols = df.select_dtypes(include=['number']).columns
    df[numeric_cols] = df[numeric_cols].fillna(df[numeric_cols].mean())

    le = LabelEncoder()
    df['Target'] = le.fit_transform(df['Target'])
    
    scaler = StandardScaler()
    cols_to_scale = ['Admission grade', 'Age at enrollment']
    df[cols_to_scale] = scaler.fit_transform(df[cols_to_scale])

    df['Age_Bins'] = pd.cut(df['Age at enrollment'], bins=3, labels=[0, 1, 2])

    important_cols = ['Target', 'Admission grade', 'Age at enrollment', 'Debtor', 'Scholarship holder', 'Age_Bins']
    df_final = df[important_cols]

    
    df_final.to_csv('data_preprocessed.csv', index=False)
    print("✅ Step 2 Success: Preprocessing complete!")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Please provide input file path")
        sys.exit(1)
    preprocess(sys.argv[1])
    
    subprocess.run([sys.executable, 'analytics.py', 'data_preprocessed.csv'], check=True)