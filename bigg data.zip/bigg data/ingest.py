import pandas as pd
import subprocess
import sys

if __name__ == "__main__":
    if len(sys.argv) < 2:
       print("Please provide dataset path")
       sys.exit(1)
    file_path = sys.argv[1]
    
    data = pd.read_csv(file_path, sep=';')
    data.columns = data.columns.str.strip().str.replace('\t', '')
    data.to_csv('data_raw.csv', index=False)
    
    print("✅ Success! Raw data is ready.")
    
    subprocess.run([sys.executable, 'preprocess.py', 'data_raw.csv'], check=True)