#!/bin/bash

CONTAINER_NAME="bigg-data"
HOST_RESULTS="./customer-analytics/results/"

mkdir -p "$HOST_RESULTS"
mkdir -p "$HOST_RESULTS/plots"

echo "📦 Copying output files from container..."

docker cp "$CONTAINER_NAME":/app/pipeline/data_raw.csv           "$HOST_RESULTS"
docker cp "$CONTAINER_NAME":/app/pipeline/data_preprocessed.csv  "$HOST_RESULTS"
docker cp "$CONTAINER_NAME":/app/pipeline/data_clustered.csv     "$HOST_RESULTS"
docker cp "$CONTAINER_NAME":/app/pipeline/insight1.txt           "$HOST_RESULTS"
docker cp "$CONTAINER_NAME":/app/pipeline/insight2.txt           "$HOST_RESULTS"
docker cp "$CONTAINER_NAME":/app/pipeline/insight3.txt           "$HOST_RESULTS"
docker cp "$CONTAINER_NAME":/app/pipeline/clusters.txt           "$HOST_RESULTS"
docker cp "$CONTAINER_NAME":/app/pipeline/plots/summary_plot.png       "$HOST_RESULTS"
docker cp "$CONTAINER_NAME":/app/pipeline/plots/.               "$HOST_RESULTS/plots/"

echo "✅ All files copied to $HOST_RESULTS"

docker stop "$CONTAINER_NAME"
docker rm   "$CONTAINER_NAME"

echo "✅ Container stopped and removed."