import pandas as pd
import subprocess
import sys

def generate_insights():
    df = pd.read_csv('data_preprocessed.csv')

    avg_age = df['Age at enrollment'].mean()
    insight1 = f"The average scaled age of students in this dataset is: {avg_age:.2f}"
    
    with open('insight1.txt', 'w') as f:
        f.write(insight1)

  
    debtor_count = df['Debtor'].value_counts(normalize=True).get(1, 0) * 100
    insight2 = f"Percentage of students with outstanding debt: {debtor_count:.2f}%"
    
    with open('insight2.txt', 'w') as f:
        f.write(insight2)

    avg_grade = df['Admission grade'].mean()
    insight3 = f"The mean admission grade (scaled) across all students is: {avg_grade:.2f}"
    
    with open('insight3.txt', 'w') as f:
        f.write(insight3)

    print("✅ Step 4 Success: 3 Insights generated and saved as .txt files!")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Please provide input file path")
        sys.exit(1)
    file_path = sys.argv[1]
    generate_insights()
    subprocess.run([sys.executable, 'visualize.py', 'data_preprocessed.csv'], check=True)