#!/bin/bash

CONTAINER_NAME="student-dropout-container"
HOST_RESULTS="./customer-analytics/results/"

mkdir -p "$HOST_RESULTS"

docker cp "$CONTAINER_NAME":/app/pipeline/data_raw.csv "$HOST_RESULTS"
docker cp "$CONTAINER_NAME":/app/pipeline/data_preprocessed.csv "$HOST_RESULTS"
docker cp "$CONTAINER_NAME":/app/pipeline/data_clustered.csv "$HOST_RESULTS"
docker cp "$CONTAINER_NAME":/app/pipeline/insight1.txt "$HOST_RESULTS"
docker cp "$CONTAINER_NAME":/app/pipeline/insight2.txt "$HOST_RESULTS"
docker cp "$CONTAINER_NAME":/app/pipeline/insight3.txt "$HOST_RESULTS"
docker cp "$CONTAINER_NAME":/app/pipeline/summary_plot.png "$HOST_RESULTS"
docker cp "$CONTAINER_NAME":/app/pipeline/clusters.txt "$HOST_RESULTS"

echo "✅ All files copied to $HOST_RESULTS"

docker stop "$CONTAINER_NAME"
docker rm "$CONTAINER_NAME"

echo "✅ Container stopped and removed."